<?php
  $wpplugin_plugins_url = plugins_url( '/', __FILE__ );
  echo $wpplugin_plugins_url;
