<div class="wrap">

  <h1><?php esc_html_e( get_admin_page_title() ); ?></h1>

  <h2><?php esc_html_e( 'Custom Footer Text', 'wpplugin' ); ?></h2>
  <p><?php esc_html_e( get_option( 'wpplugin_options' ) ); ?></p>

</div>
