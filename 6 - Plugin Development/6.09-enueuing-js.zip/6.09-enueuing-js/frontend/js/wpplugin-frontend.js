alert( 'Plugin frontend JavaScript loaded.' );
