<div class="post-ad">
  <p>Here is a special ad!!!</p>
</div>
