<div class="contact-support-cta">
  <h2><?php esc_html_e( 'Please open a support ticket for technical support', 'wphooks' ); ?></h2>
</div>
