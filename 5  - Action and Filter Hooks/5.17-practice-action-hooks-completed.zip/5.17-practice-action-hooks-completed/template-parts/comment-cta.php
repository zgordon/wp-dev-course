<div class="comment-cta">
  <h2><?php esc_html_e( 'Join in the Discussion!!!', 'wphooks' ); ?></h2>
</div>
