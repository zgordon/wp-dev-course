<p><?php _e( 'Before Footer Custom Message.', 'wphooks' ); ?></p>
