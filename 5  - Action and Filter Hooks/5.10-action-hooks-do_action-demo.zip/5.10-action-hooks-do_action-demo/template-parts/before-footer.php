<p><?php _e( 'My custom footer template!', 'wphooks' ); ?></p>
