
    <footer id="colophon" class="site-footer" role="contentinfo">

    </footer>

    <?php wp_footer(); ?>

  </div><!-- #content -->

</div><!-- #footer -->

</body>
</html>
