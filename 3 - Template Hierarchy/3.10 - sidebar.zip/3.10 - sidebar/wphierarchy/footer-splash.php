
    <div class="notice">
      <p>Don't forget to sign up!</p>
    </div>

    <?php wp_footer(); ?>

  </div><!-- #content -->

</div><!-- #footer -->

</body>
</html>
