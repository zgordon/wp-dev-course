<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>WP Hierarchy</title>
  </head>
  <body>

    <h1>index.php</h1>

  </body>
</html>
