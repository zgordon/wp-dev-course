<?php get_header(); ?>

    <h1>index.php</h1>

  </body>
</html>
