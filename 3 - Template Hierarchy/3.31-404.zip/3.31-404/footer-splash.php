
  </div><!-- #content -->

  <footer id="colophon" class="site-footer" role="contentinfo">

    <div class="notice">
      <p>Don't forget to sign up!</p>
    </div>

  </footer>

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
