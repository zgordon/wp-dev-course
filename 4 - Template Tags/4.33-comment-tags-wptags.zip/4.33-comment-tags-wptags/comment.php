<div class="comment">

  <?php comment_author(); ?>
  @
  <?php comment_date( 'm.d.y g:ia' ); ?>

  <?php comment_text(); ?>

</div>
