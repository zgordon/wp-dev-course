<?php get_header(); ?>

    <div id="content">

      <!-- Static Front Page -->

      <!-- Blog Home -->

      <!-- Page (Not Front Page) -->

      <!-- Single Post -->

      <!-- Single Attachment (Media) -->

      <!-- Category Archive -->

      <!-- Tag Archive -->

      <!-- Author Archive -->

      <!-- Date Archive -->

      <!-- 404 Page -->

    </div>

<?php get_footer(); ?>
